/*
Create a function `odd` which only keep odd values from an array passed as an argument.

You can't use a loop!

Don't mutate the parameter.

*/

// TODO add your code here
